/*
* Activity 1.2.3
*/
public class CakeRunnerFlow
{
  public static void main(String[] args)
  {
    // cake 2
    Cake cake2;
    System.out.println();
    System.out.println("Congratulations!");
    cake2 = new Cake(2);
    cake2.addCandles();
    cake2.show();
  }
}
