/*
* Activity 1.2.3
*
* Another CakeRunner class
*/
public class CakeRunner2
{
  public static void main(String[] args)
  {
    // cake 1
    System.out.println();
    System.out.println("Happy Birthday!");
    Cake cake1 = new Cake();
    cake1.oneTier();
    cake1.show();
    System.out.println("Do you like your cake?");
    
  }
}